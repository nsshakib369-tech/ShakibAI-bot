import os
import uuid
from datetime import datetime, timezone
from typing import Any

from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

load_dotenv()
app = FastAPI(title="SHAKIB AI Backend", version="0.1.0")
API_KEY = os.getenv("SHAKIB_AI_API_KEY", "change-this-development-key")


class CommandRequest(BaseModel):
    command: str = Field(min_length=1, max_length=5000)
    source: str = "android_voice"
    locale: str = "en-MY"


class CommandResponse(BaseModel):
    task_id: str
    status: str
    command: str
    message: str
    next_step: str | None = None
    requires_confirmation: bool = False
    available_tools: list[str] = []


def require_key(x_api_key: str | None):
    if not x_api_key or x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")


@app.get("/health")
def health():
    return {"status": "ok", "service": "SHAKIB AI", "version": "0.1.0"}


@app.post("/api/command", response_model=CommandResponse)
def submit_command(body: CommandRequest, x_api_key: str | None = Header(default=None)):
    require_key(x_api_key)
    command = body.command.strip()
    if not command:
        raise HTTPException(status_code=422, detail="Command cannot be empty")

    # Conservative safety gate: actual integrations should classify each tool/action.
    action_words = ("delete", "remove", "send", "email", "message", "update", "change",
                    "create lead", "add customer", "close deal", "purchase", "pay")
    needs_confirmation = any(word in command.lower() for word in action_words)

    mcp_url = os.getenv("SALES_MCP_URL", "").strip()
    if mcp_url:
        tools = ["Sales MCP configured (adapter implementation required)"]
    else:
        tools = ["CRM/customer leads (not connected yet)", "Sales reports (not connected yet)"]

    return CommandResponse(
        task_id=str(uuid.uuid4()),
        status="received",
        command=command,
        message=(
            "Your voice command was received by SHAKIB AI. "
            "The starter backend is running, but an AI provider and Sales-Management MCP "
            "tool adapter still need to be configured before it can execute real work."
        ),
        next_step="Configure an AI provider and the exact Sales-Management MCP endpoint/protocol.",
        requires_confirmation=needs_confirmation,
        available_tools=tools,
    )


@app.get("/api/tools")
def list_tools(x_api_key: str | None = Header(default=None)):
    require_key(x_api_key)
    if not os.getenv("SALES_MCP_URL", "").strip():
        return {
            "connected": False,
            "tools": [],
            "message": "Set SALES_MCP_URL and implement the server's documented MCP transport/auth."
        }
    return {
        "connected": False,
        "tools": [],
        "message": "Endpoint configured, but MCP discovery/call adapter must be implemented and tested."
    }
