package com.shakibai.voiceassistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int SPEECH_REQUEST = 100;
    private static final int AUDIO_PERMISSION_REQUEST = 101;
    private EditText commandBox, backendBox, keyBox;
    private TextView statusView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 32, 32, 32);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("SHAKIB AI");
        title.setTextSize(30);
        title.setPadding(0, 0, 0, 8);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Voice-controlled work assistant · v0.1");
        subtitle.setTextSize(15);
        root.addView(subtitle);

        addLabel(root, "Backend URL (use your PC's LAN IP on a real phone)");
        backendBox = new EditText(this);
        backendBox.setSingleLine(true);
        backendBox.setText("http://10.0.2.2:8000");
        backendBox.setHint("http://192.168.1.20:8000");
        root.addView(backendBox, matchWidth());

        addLabel(root, "Backend API key");
        keyBox = new EditText(this);
        keyBox.setSingleLine(true);
        keyBox.setText("change-this-development-key");
        keyBox.setHint("Same value as backend .env");
        root.addView(keyBox, matchWidth());

        addLabel(root, "Your command");
        commandBox = new EditText(this);
        commandBox.setMinLines(3);
        commandBox.setGravity(0x00800003);
        commandBox.setHint("Example: Prepare a sales report for this week");
        root.addView(commandBox, matchWidth());

        Button recordButton = new Button(this);
        recordButton.setText("🎙 Record voice command");
        recordButton.setOnClickListener(v -> startSpeech());
        root.addView(recordButton, matchWidth());

        Button sendButton = new Button(this);
        sendButton.setText("Send command to SHAKIB AI");
        sendButton.setOnClickListener(v -> submitCommand());
        root.addView(sendButton, matchWidth());

        statusView = new TextView(this);
        statusView.setText("Ready. Tap Record to speak; review the transcript before sending.");
        statusView.setTextSize(16);
        statusView.setPadding(0, 24, 0, 0);
        root.addView(statusView, matchWidth());

        TextView privacy = new TextView(this);
        privacy.setText("\nPrivacy: no background listening. Speech recognition may use your device's configured recognition service. Only the text you submit is sent to your backend.");
        privacy.setTextSize(12);
        root.addView(privacy);

        setContentView(scroll);
    }

    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(14);
        label.setPadding(0, 20, 0, 4);
        root.addView(label);
    }

    private LinearLayout.LayoutParams matchWidth() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void startSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition is not available on this device.", Toast.LENGTH_LONG).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION_REQUEST);
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your SHAKIB AI command");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        try {
            startActivityForResult(intent, SPEECH_REQUEST);
        } catch (Exception e) {
            Toast.makeText(this, "Could not start speech recognition: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                commandBox.setText(results.get(0));
                statusView.setText("Transcript ready. Review or edit it, then tap Send.");
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AUDIO_PERMISSION_REQUEST && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startSpeech();
        } else if (requestCode == AUDIO_PERMISSION_REQUEST) {
            Toast.makeText(this, "Microphone permission is needed for voice commands.", Toast.LENGTH_LONG).show();
        }
    }

    private void submitCommand() {
        final String command = commandBox.getText().toString().trim();
        final String baseUrl = backendBox.getText().toString().trim().replaceAll("/+$", "");
        final String apiKey = keyBox.getText().toString().trim();
        if (command.isEmpty()) {
            commandBox.setError("Enter or record a command first");
            return;
        }
        if (baseUrl.isEmpty() || apiKey.isEmpty()) {
            statusView.setText("Enter backend URL and API key.");
            return;
        }
        statusView.setText("Sending command…");
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(baseUrl + "/api/command");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(20000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("X-API-Key", apiKey);
                JSONObject payload = new JSONObject();
                payload.put("command", command);
                payload.put("source", "android_voice");
                payload.put("locale", Locale.getDefault().toLanguageTag());
                byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
                int code = connection.getResponseCode();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        code >= 200 && code < 400 ? connection.getInputStream() : connection.getErrorStream(),
                        StandardCharsets.UTF_8));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) response.append(line);
                reader.close();
                JSONObject json = new JSONObject(response.toString());
                String message = json.optString("message", response.toString());
                String taskId = json.optString("task_id", "");
                String next = json.optString("next_step", "");
                boolean confirm = json.optBoolean("requires_confirmation", false);
                String result = "HTTP " + code + "\nTask: " + taskId + "\n\n" + message
                        + (confirm ? "\n\nConfirmation required before any modifying action." : "")
                        + (next.isEmpty() ? "" : "\n\nNext: " + next);
                runOnUiThread(() -> statusView.setText(result));
            } catch (Exception e) {
                runOnUiThread(() -> statusView.setText(
                        "Could not reach backend: " + e.getMessage()
                        + "\nCheck backend URL, Wi-Fi, API key, and that FastAPI is running."));
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
