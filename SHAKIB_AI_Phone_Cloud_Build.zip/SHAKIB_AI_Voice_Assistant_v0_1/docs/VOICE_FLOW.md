# Voice command flow

1. User taps Record.
2. Android requests microphone permission if needed.
3. Android launches the configured speech recognition service.
4. Recognized transcript is placed into an editable text field.
5. User reviews and taps Send.
6. Android sends only the transcript to the authenticated backend.
7. Backend responds with a task ID, status, and message.

This starter uses speech-to-text rather than keeping a raw audio recording. If you want audio files saved, add a separate explicit record/save workflow with clear retention controls.
