# Sales-Management MCP integration

The starter backend intentionally does not guess the MCP protocol or endpoint.

Before implementing real tool calls, obtain:
1. Exact MCP server URL and transport (e.g. documented Streamable HTTP/SSE or a provider-specific gateway).
2. Authentication method and required headers.
3. Tool discovery response/schema.
4. Tool invocation request/response examples.
5. Which tools are read-only vs. write/side-effecting.

Then implement a server-side adapter in `backend/app/`:
- Discover tools from the actual MCP server.
- Expose only allowlisted tools to the planner.
- Validate arguments against the server's schemas.
- Require explicit user confirmation before external side effects.
- Never expose MCP tokens or LLM keys to Android.
- Log task IDs and outcomes without storing raw voice recordings unless explicitly enabled.

Do not call tools merely because a user command mentions them. Parse the intent, present the planned actions, and require confirmation for updates, messages, deletes, purchases, or other external changes.
