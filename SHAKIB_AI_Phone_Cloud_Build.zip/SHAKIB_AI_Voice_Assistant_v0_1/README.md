# SHAKIB AI Voice Assistant v0.1

Starter project: Android (Java) voice-command client + Python FastAPI backend.

## Features
- Android push-to-talk speech recognition using Android `SpeechRecognizer`.
- Review/edit recognized text before sending.
- Sends commands to a configurable backend URL.
- Backend returns a safe starter response and includes a clear adapter seam for your Sales-Management MCP tools.
- API-key authentication between Android client and backend.
- No background listening. The microphone is used only after the user taps Record.

## Project structure
- `android/` — Android Studio project (Java)
- `backend/` — Python FastAPI service
- `docs/` — integration notes

## Important
This is a runnable starter scaffold, not a fully connected AI agent yet. The exact MyChatBot Sales-Management MCP endpoint, authentication scheme, and tool protocol must be configured before real CRM actions can run. Do not put provider/API secrets in the Android app.

## Run backend locally
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
For a physical Android phone, `127.0.0.1` points to the phone itself. Use your PC's LAN IP as the backend URL, e.g. `http://192.168.1.20:8000`, and keep phone and PC on the same Wi-Fi. Android cleartext HTTP is enabled only for this development scaffold; use HTTPS for production.

## Run Android
1. Open `android/` in Android Studio.
2. Let Gradle sync.
3. Run on an Android device or emulator.
4. Set the backend URL in the app to your reachable backend address.
5. Set the same API key in Android settings and backend `.env`.

## Production checklist
- Put backend behind HTTPS.
- Replace development API key.
- Add persistent user/task storage.
- Connect an actual LLM provider on the backend.
- Implement MCP discovery/calls using the exact server protocol.
- Add per-tool permissions and confirmation gates for destructive/external actions.
- Add rate limiting, audit logs, and privacy/retention controls.
