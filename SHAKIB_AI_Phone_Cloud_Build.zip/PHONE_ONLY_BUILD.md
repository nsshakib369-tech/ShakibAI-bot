# Build SHAKIB AI APK using only your Android phone

This ZIP includes a GitHub Actions workflow that builds a debug APK in the cloud.
You still need a GitHub account and must upload the project to a repository using your phone browser.

## Steps
1. Open https://github.com in your phone browser and sign in or create an account.
2. Create a NEW repository, e.g. `shakib-ai-voice-assistant`. A private repository is recommended.
3. Extract this ZIP with a file manager that supports ZIP extraction.
4. Upload the extracted project files/folders to the repository root using GitHub's website. Ensure `.github/workflows/build-apk.yml` is included. If the mobile website doesn't allow folder uploads, use GitHub's browser upload interface or GitHub's official mobile app/browser in desktop mode.
5. Open the repository's Actions tab. Select `Build SHAKIB AI APK` and tap `Run workflow`. If prompted, enable Actions.
6. Wait for the run to finish successfully. Open the completed run and download the `SHAKIB-AI-debug-APK` artifact.
7. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Tap the APK and allow your browser/file manager to install apps when Android asks.
8. If the workflow fails, open the failed run and share the error log so it can be fixed.

## Important limitations
- The APK is a debug build, not a Play Store release.
- This app sends text commands to a Python backend; this build does not host the backend on the phone.
- The backend must be running at a reachable URL, and the Android app's backend URL and API key must match it.
- The current backend is a starter scaffold. It does not yet execute live AI or MCP tools.
- Do not use a real secret in a public repository. Keep the repository private and replace the development key before deployment.
